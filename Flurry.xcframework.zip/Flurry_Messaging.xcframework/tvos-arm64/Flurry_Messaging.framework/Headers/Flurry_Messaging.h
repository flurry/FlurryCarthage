//
//  Flurry_Messaging.h
//  Flurry
//
//  Copyright © 2022 Yahoo! Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Flurry_Messaging.
FOUNDATION_EXPORT double Flurry_MessagingVersionNumber;

//! Project version string for Flurry_Messaging.
FOUNDATION_EXPORT const unsigned char Flurry_MessagingVersionString[];

#import <Flurry_Messaging/FlurryMessaging.h>
