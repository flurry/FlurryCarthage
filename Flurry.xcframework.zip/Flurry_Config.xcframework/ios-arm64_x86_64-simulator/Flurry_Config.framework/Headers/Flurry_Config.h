//
//  Flurry_Config.h
//  Flurry
//
//  Copyright © 2022 Yahoo! Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Flurry_Config.
FOUNDATION_EXPORT double Flurry_ConfigSDKVersionNumber;

//! Project version string for Flurry_Config.
FOUNDATION_EXPORT const unsigned char Flurry_ConfigSDKVersionString[];

#import <Flurry_Config/FConfig.h>
